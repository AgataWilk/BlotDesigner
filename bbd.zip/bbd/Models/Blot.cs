﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace bbd.Models
{
    public class Blot
    {
        private bbdContext context;
        public int Id { get; set; }
        public DateTime BlotDate { get; set; }
        public int UserId { get; set; }
        public string ProteinId { get; set; }
        public int LadderId { get; set; }
        public int PAId { get; set; }
        public int SAId { get; set; }

        public float ProteinAmount { get; set; }
        public float PAAmount { get; set; }
        public float SAAmount { get; set; }
        public float LadderAmount { get; set; }
        public byte Scan { get; set; }
        public float GelConcentration { get; set; }

        public string Comment { get; set; }


    }
}
