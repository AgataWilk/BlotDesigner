﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BlotDesigner.Models
{
    public class UserModel
    {
        [Display(Name="Imię")]
        [Required(ErrorMessage ="Musisz podać imię")]
        public string FirstName { get; set; }

        [Display(Name = "Nazwisko")]
        [Required(ErrorMessage = "Musisz podać nazwisko")]
        public string LastName { get; set; }

        [Display(Name = "Instytucja")]
        [Required(ErrorMessage = "Musisz podać instytucję")]
        public string Institute { get; set; }

        [Display(Name = "Login")]
        [Required(ErrorMessage = "Musisz wybrać login")]
        public string Login { get; set; }

        [Display(Name ="Hasło")]
        [DataType(DataType.Password)]
        [StringLength(100, MinimumLength = 8, ErrorMessage ="Hasło jest za krótkie")]
        public string Password { get; set; }

        [Display(Name ="Powtórz hasło")]
        [DataType(DataType.Password)]
        [Compare("Password",ErrorMessage ="Hasła muszą się zgadzać")]
        public string repeatPassword { get; set; }

    }
}