﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace bbd.Models
{
    public class bbdContext
    {
        public string ConnectionString { get; set; }

        public bbdContext(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(ConnectionString);
        }

        public User GetUser(int id)
        {
            User czlowiek = new User();

            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("select * from users where user_id = @id", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        czlowiek.Id = Convert.ToInt32(reader["user_id"]);
                        czlowiek.FirstName = reader["user_name"].ToString();
                        czlowiek.LastName = reader["user_surname"].ToString();
                        czlowiek.Institute = reader["user_institute"].ToString();
                        czlowiek.Login = reader["user_login"].ToString();
                        czlowiek.Password = reader["user_password"].ToString();

                    }
                }
            }
            return czlowiek;
        }

        public void ChangeUser(int id, string name, string surname, string institute, string password)
        {
            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("UPDATE users SET user_name = @name, user_surname = @surname, user_institute = @institute, user_password = @password where user_id = @id", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {

                    }
                }
            }
            
        }

        public int AddUser(string name, string surname, string institute, string login, string password)
        {
            int count;
            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand check = new MySqlCommand("SELECT COUNT(user_id) FROM users WHERE user_login = @login", conn);
                MySqlCommand cmd = new MySqlCommand("INSERT INTO users(user_name,user_surname,user_institute,user_login,user_password) VALUES(@name,@surname,@institute,@login,@password)", conn);
                count = Convert.ToInt32(check.ExecuteScalar());
                if(count != 0)
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {

                        }
                    }
                }
                
            }
            return count;
        }

        public List<Blot> GetBlot(int id)
        {
            List<Blot> list = new List<Blot>();

            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("select * from blot where user_id = @id", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Blot()
                        {
                            Id = Convert.ToInt32(reader["blot_id"]),
                            BlotDate = Convert.ToDateTime(reader["blot_date"]),
                            UserId = Convert.ToInt32(reader["user_id"]),
                            ProteinId = reader["blot_protein_id"].ToString(),
                            LadderId = Convert.ToInt32(reader["blot_ladder_id"]),
                            PAId = Convert.ToInt32(reader["blot_pa_id"]),
                            SAId = Convert.ToInt32(reader["blot_sa_id"]),
                            ProteinAmount = (float)Convert.ToDouble(reader["protein_amount"]),
                            PAAmount = (float) Convert.ToDouble(reader["pa_amount"]),
                            SAAmount = (float)Convert.ToDouble(reader["sa_amount"]),
                            LadderAmount = (float)Convert.ToDouble(reader["ladder_amount"]),
                            Scan = Convert.ToByte(reader["blot_scan"]),
                            GelConcentration = (float)Convert.ToDouble(reader["ladder_amount"]),
                            Comment = reader["user_comment"].ToString()
                        });

                    }
                }
            }
            return list;
        }

    }
}
