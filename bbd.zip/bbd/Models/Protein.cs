﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace bbd.Models
{
    public class Protein
    {
        public string ProteinId { get; set; }
        
    }
}
