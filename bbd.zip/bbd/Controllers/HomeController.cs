﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using bbd.Models;

namespace bbd.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Zaloguj()
        {
            return View();
        }

        public IActionResult Zarejestruj()
        {
            return View();
        }

        public IActionResult Profil()
        {
            return View();
        }

        public IActionResult Edycjaprofilu()
        {
            return View();
        }
        public IActionResult Dodajblot()
        {
            return View();
        }
        public IActionResult Podejrzyjblot()
        {
            return View();
        }

    }
}
