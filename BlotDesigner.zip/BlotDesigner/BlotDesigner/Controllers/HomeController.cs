﻿using BlotDesigner.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MySql.Data.MySqlClient;

namespace BlotDesigner.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Blot Designer.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Register()
        {
            ViewBag.Message = "Sign up. ";

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(UserModel model)
        {
            if(ModelState.IsValid)
            {
                string connectionString = "server=remotemysql.com;port=3306;Database=VeU3XcqsL9;user=VeU3XcqsL9;password=DX23PAgiQ2;Allow User Variables=True";
                MySqlConnection conn = new MySqlConnection(connectionString);
                MySqlCommand check = new MySqlCommand("SELECT COUNT(user_id) FROM users WHERE user_login = @Login", conn);
                MySqlCommand number = new MySqlCommand("SELECT COUNT(user_id) FROM users", conn);

                conn.Open();
                MySqlCommand cmd = new MySqlCommand();
                check.Parameters.AddWithValue("@Login", model.Login);
                number.Parameters.AddWithValue("@Login", model.Login);

                cmd.Connection = conn;
                int logintaken = Convert.ToInt32(check.ExecuteScalar());
                int count = Convert.ToInt32(number.ExecuteScalar());

                if (logintaken == 0)
                {
                    cmd.CommandText = "INSERT into users(user_id,user_name,user_surname,user_institute,user_login,user_password) values(@id,@Name,@Surname,@Institute,@Login,@Password)";
                    cmd.Prepare();
                    cmd.Parameters.AddWithValue("@Name", model.FirstName);
                    cmd.Parameters.AddWithValue("@Surname", model.LastName);
                    cmd.Parameters.AddWithValue("@Institute", model.Institute);
                    cmd.Parameters.AddWithValue("@Login", model.Login);
                    cmd.Parameters.AddWithValue("@Password", model.Password);
                    cmd.Parameters.AddWithValue("@id", count+1);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return RedirectToAction("About");

                }
                else
                {
                    Response.Write("<script>alert('login zajęty');</script>");
                }
                
            }

            return View();
        }

        public ActionResult LogIn()
        {
            ViewBag.Message = "Log in. ";

            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogIn(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                string connectionString = "server=remotemysql.com;port=3306;Database=VeU3XcqsL9;user=VeU3XcqsL9;password=DX23PAgiQ2;Allow User Variables=True";
                MySqlConnection conn = new MySqlConnection(connectionString);
                MySqlCommand userid = new MySqlCommand("SELECT user_id FROM users WHERE user_login = @Login AND user_password = @Password ", conn);

                conn.Open();
                userid.Parameters.AddWithValue("@Login", model.Login);
                userid.Parameters.AddWithValue("@Password", model.Password);
                var goodlogin = userid.ExecuteScalar();
                conn.Close();
                if (goodlogin != null)
                {
                    return RedirectToAction("About",new { id = Convert.ToInt32(goodlogin) });

                }
                else
                {
                    Response.Write("<script>alert('Nieprawidłowy login lub hasło');</script>");
                }

            }

            return View();
        }

        public ActionResult EditProfile()
        {
            ViewBag.Message = "Edit your info. ";

            return View();
        }
    }
}